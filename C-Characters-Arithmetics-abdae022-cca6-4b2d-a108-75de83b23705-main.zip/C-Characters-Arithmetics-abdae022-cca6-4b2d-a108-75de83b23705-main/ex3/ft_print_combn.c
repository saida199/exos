/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saida.koci <saida.koci@learner.42.tech>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/28 18:51:30 by saida.koci        #+#    #+#             */
/*   Updated: 2025/07/29 19:21:24 by saida.koci       ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
#include <unistd.h>
void	write_number(char c[10], int n)
{	int	i;

	while (c[0] <= 10 - n +'0')

	{
		write (1, c, n);
		if (c[0] < 10 - n + '0')
		{
		write(1, ", ", 2);
		}
		i = n - 1;
		while (i >= 0 && c[i] == '9' - (n - 1 - i))
		{
			i--;
		}
		if (i < 0)
		{
		return;
		}
		c[i]++;
		while (i++ < n)
{
		c[i]++;
		while (i++ < n)
		{
			c[i] = c[i - 1] + 1;
		}
	}
}
	void	ft_print_combn(int n)
	{
	char	c[10];
	int	i;
		if (n <= 0) || n >= 10)
		{
		return ;
		}
	i = -1;
		while (++i < n)
		{
			c[i] = i + '0';
		}
		write_number(c, n);

}*/

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	print_comb(int *comb, int n)
{
	int	i;

	i = 0;
	while (i < n)
		ft_putchar(comb[i++] + '0');
	if (comb[0] != 10 - n)
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	comb_rec(int *comb, int depth, int n, int start)
{
	int	i;

	if (depth == n)
	{
		print_comb(comb, n);
		return ;
	}
	i = start;
	while (i <= 9)
	{
		comb[depth] = i;
		comb_rec(comb, depth + 1, n, i + 1);
		i++;
	}
}

void	ft_print_combn(int n)
{
	int	comb[10];

	if (n < 1 || n > 9)
		return ;
	comb_rec(comb, 0, n, 0);
}
/*
int main ()
{
	ft_print_combn(2);
	return 0;
}*/
